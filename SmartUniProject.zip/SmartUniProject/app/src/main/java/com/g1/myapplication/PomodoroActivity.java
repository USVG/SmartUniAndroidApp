package com.g1.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.provider.AlarmClock;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.snackbar.Snackbar;

public class PomodoroActivity  extends AppCompatActivity {

    Integer studyCounter;
    Integer breakCounter;
    EditText mStudyTimerEditText;
    EditText mBreakTimerEditText;
    Button mButtonStartStudy;
    Button mButtonStartBreak;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.pomodoro_activity);

        studyCounter = 1;
        breakCounter = 1;

        Button button = findViewById(R.id.GoBackFromPomodoro);

//      Listener for the go back button
        button.setOnClickListener(v -> {
            Intent intent1 = new Intent(this, MainActivity.class);

            startActivity(intent1);
        });

        mStudyTimerEditText = (EditText) findViewById(R.id.InputboxStudyDuration);
        mBreakTimerEditText = (EditText) findViewById(R.id.InputboxBreakDuration);
        mButtonStartStudy = (Button) findViewById(R.id.ButtonStartStudy);
        mButtonStartBreak = (Button) findViewById(R.id.ButtonStartBreak);


//      Listener for start study button
        mButtonStartStudy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int studyDuration = Integer.parseInt(mStudyTimerEditText.getText().toString());

                if (studyDuration > 0) {
                    Intent intent1 = new Intent(AlarmClock.ACTION_SET_TIMER);
                    intent1.putExtra(AlarmClock.EXTRA_LENGTH, (studyDuration * 60));
                    intent1.putExtra(AlarmClock.EXTRA_MESSAGE, ("Study " + studyCounter));
                    studyCounter = studyCounter + 1;
                    startActivity(intent1);
                } else {
                    Snackbar.make(v, "Error: Invalid Study Duration Input", Snackbar.LENGTH_LONG)
                            .setAction("Action", null).show();
                }

            }
        });

//      Listener for break button
        mButtonStartBreak.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int breakDuration = Integer.parseInt(mBreakTimerEditText.getText().toString());

                if (breakDuration > 0) {
                    Intent intent1 = new Intent(AlarmClock.ACTION_SET_TIMER);
                    intent1.putExtra(AlarmClock.EXTRA_LENGTH, (breakDuration * 60));
                    intent1.putExtra(AlarmClock.EXTRA_MESSAGE, ("Break " + breakCounter));
                    breakCounter = breakCounter + 1;
                    startActivity(intent1);
                } else {
                    Snackbar.make(v, "Error: Invalid Break Duration Input", Snackbar.LENGTH_LONG)
                            .setAction("Action", null).show();
                }
            }
        });
    }
}
