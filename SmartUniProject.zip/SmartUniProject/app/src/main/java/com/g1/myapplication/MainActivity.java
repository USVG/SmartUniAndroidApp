package com.g1.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button button  = findViewById(R.id.ButtonGoToAlarm);
        Button button1  = findViewById(R.id.ButtonGoToPomodoro);


//      Listener for the go to alarm button
        button.setOnClickListener(v -> {
            Intent intent1 = new Intent(this, AlarmActivity.class);

            startActivity(intent1);
        });

//      Listener for the go to pomodoro button
        button1.setOnClickListener(v -> {
            Intent intent1 = new Intent(this, PomodoroActivity.class);

            startActivity(intent1);
        });
    }

}