package com.g1.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.provider.AlarmClock;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.snackbar.Snackbar;

public class AlarmActivity extends AppCompatActivity {

    EditText mHourEditText;
    EditText mMinuteEditText;
    EditText mMessageEditText;
    Button mButtonSetAlarm;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.alarm_activity);

        Button button = findViewById(R.id.ButtonGoBackFromAlarm);

//      Listener for go back button
        button.setOnClickListener(v -> {
            Intent intent1 = new Intent(this, MainActivity.class);

            startActivity(intent1);
        });

        mHourEditText = (EditText) findViewById(R.id.InputboxHour);
        mMinuteEditText = (EditText) findViewById(R.id.InputboxMinute);
        mMessageEditText = (EditText) findViewById(R.id.InputboxAlarmMessage);
        mButtonSetAlarm = (Button) findViewById(R.id.ButtonSetAlarm);

//      Listener for the set alarm button
        mButtonSetAlarm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int hour = Integer.parseInt(mHourEditText.getText().toString());
                int minute = Integer.parseInt(mMinuteEditText.getText().toString());
                String message = mMessageEditText.getText().toString();


                if (hour <= 23 && minute <= 59) {
                    Intent intent = new Intent(AlarmClock.ACTION_SET_ALARM);
                    intent.putExtra(AlarmClock.EXTRA_HOUR, hour);
                    intent.putExtra(AlarmClock.EXTRA_MINUTES, minute);
                    intent.putExtra(AlarmClock.EXTRA_MESSAGE, message);

                    startActivity(intent);
                }
                else {
                    Snackbar.make(view, "Error: Invalid Input", Snackbar.LENGTH_LONG)
                            .setAction("Action", null).show();
                }
            }
        });

        };
}


